
# Set up Staging Preview
- [ ] Create `.env.staging` in frontend <!-- id: 10 -->
- [ ] Start Staging Frontend on port 5176 <!-- id: 11 -->
- [ ] Add "View Staging" button to Admin Dashboard <!-- id: 12 -->
