// "Competitor Q" = QNAP, "Competitor S" = Synology
export const PERFORMANCE_DATA = [
  { name: 'Competitor Q', iops: 45000, throughput: 2200 },
  { name: 'Competitor S', iops: 42000, throughput: 2100 },
  { name: 'QuickStor Z-Series', iops: 125000, throughput: 6500 }, // The Clear Winner
];