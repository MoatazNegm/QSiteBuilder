import React from 'react';
import LoginForm from '../features/auth/LoginForm';

const Login = () => {
  return <LoginForm />;
};

export default Login;