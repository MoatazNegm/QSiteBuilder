
# Task: Add Controls to Staging Banner

- [ ] Check Backend API for publish/reject endpoints <!-- id: 13 -->
- [ ] Implement `POST /api/publish` in Backend (if missing) <!-- id: 14 -->
- [ ] Implement `POST /api/reject` in Backend (if missing) <!-- id: 15 -->
- [ ] Update `StagingBanner.jsx` with buttons and API calls <!-- id: 16 -->
